﻿using System;
using System.Collections.Generic;
using System.Threading;

class CSharpAdvancedTopics
{
    static void Main(string[] args)
    {

    }
}
