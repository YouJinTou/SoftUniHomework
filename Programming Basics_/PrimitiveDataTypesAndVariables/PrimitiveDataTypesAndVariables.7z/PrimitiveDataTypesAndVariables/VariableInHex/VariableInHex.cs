﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VariableInHex
{
    class VariableInHex
    {
        static void Main(string[] args)
        {
            byte hexInt = 0xFE;
            Console.WriteLine(hexInt);
        }
    }
}
