﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeclareVariables
{
    class VariableDeclarer
    {
        static void Main(string[] args)
        {
            uint value1 = 52130;
            sbyte value2 = -115;
            uint value3 = 4825932;
            byte value4 = 97;
            short value5 = -10000;
        }
    }
}
