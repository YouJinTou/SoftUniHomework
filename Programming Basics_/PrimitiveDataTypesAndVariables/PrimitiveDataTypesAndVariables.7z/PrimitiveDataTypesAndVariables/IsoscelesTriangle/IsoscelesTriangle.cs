﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IsoscelesTriangle
{
    class IsoscelesTriangle
    {
        static void Main(string[] args)
        {        
            Console.WriteLine("   ©");
            Console.WriteLine("  © ©");
            Console.WriteLine(" ©   ©");
            Console.WriteLine("© © © ©");
        }
    }
}
